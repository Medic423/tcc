import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  Link, 
  Activity, 
  Target, 
  BarChart3
} from 'lucide-react';

interface OptimizationMetrics {
  totalRevenue: number;
  revenuePerHour: number;
  loadedMileRatio: number;
  backhaulPairs: number;
  averageEfficiency: number;
  potentialRevenueIncrease: number;
  totalTrips: number;
  averageRevenuePerTrip: number;
  totalMiles: number;
  loadedMiles: number;
}

interface BackhaulPair {
  request1: any;
  request2: any;
  distance: number;
  timeWindow: number;
  efficiency: number;
  revenueBonus: number;
}

interface Unit {
  id: string;
  unitNumber: string;
  type: string;
  status: string;
  capabilities: string[];
  currentLocation: any;
  shiftStart: string;
  shiftEnd: string;
}

interface RevenueOptimizationPanelProps {
  showBackhaulPairs?: boolean;
  showUnitManagement?: boolean;
  title?: string;
  className?: string;
}

const RevenueOptimizationPanel: React.FC<RevenueOptimizationPanelProps> = ({
  showBackhaulPairs = true,
  showUnitManagement = true,
  title = "Revenue Optimization",
  className = ""
}) => {
  const [optimizationMetrics, setOptimizationMetrics] = useState<OptimizationMetrics | null>(null);
  const [backhaulPairs, setBackhaulPairs] = useState<BackhaulPair[]>([]);
  const [units, setUnits] = useState<Unit[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOptimizationData();
  }, []);

  const loadOptimizationData = async () => {
    try {
      setLoading(true);
      
      // Load revenue analytics
      const revenueResponse = await fetch('/api/optimize/revenue?timeframe=24h');
      if (revenueResponse.ok) {
        const revenueData = await revenueResponse.json();
        if (revenueData.success) {
          setOptimizationMetrics({
            totalRevenue: revenueData.data.totalRevenue || 0,
            revenuePerHour: revenueData.data.revenuePerHour || 0,
            loadedMileRatio: revenueData.data.loadedMileRatio || 0,
            backhaulPairs: 0, // Will be updated from backhaul data
            averageEfficiency: 0.75, // Mock data
            potentialRevenueIncrease: 0, // Will be calculated
            totalTrips: revenueData.data.totalTrips || 0,
            averageRevenuePerTrip: revenueData.data.averageRevenuePerTrip || 0,
            totalMiles: revenueData.data.totalMiles || 0,
            loadedMiles: revenueData.data.loadedMiles || 0,
          });
        }
      }

      // Load backhaul opportunities
      const backhaulResponse = await fetch('/api/optimize/backhaul');
      if (backhaulResponse.ok) {
        const backhaulData = await backhaulResponse.json();
        if (backhaulData.success) {
          setBackhaulPairs(backhaulData.data.pairs || []);
          // Update metrics with backhaul data
          setOptimizationMetrics(prev => prev ? {
            ...prev,
            backhaulPairs: backhaulData.data.pairs?.length || 0,
            potentialRevenueIncrease: backhaulData.data.pairs?.reduce((sum: number, pair: any) => sum + (pair.revenueBonus || 0), 0) || 0
          } : null);
        }
      }

      // Load units data (mock for now)
      setUnits([
        { id: '1', unitNumber: 'A-101', type: 'AMBULANCE', status: 'AVAILABLE', capabilities: ['BLS', 'ALS'], currentLocation: null, shiftStart: '08:00', shiftEnd: '20:00' },
        { id: '2', unitNumber: 'A-102', type: 'AMBULANCE', status: 'ON_CALL', capabilities: ['BLS'], currentLocation: null, shiftStart: '08:00', shiftEnd: '20:00' },
        { id: '3', unitNumber: 'A-103', type: 'AMBULANCE', status: 'AVAILABLE', capabilities: ['BLS', 'ALS', 'CCT'], currentLocation: null, shiftStart: '08:00', shiftEnd: '20:00' },
        { id: '4', unitNumber: 'V-201', type: 'WHEELCHAIR_VAN', status: 'AVAILABLE', capabilities: ['BLS'], currentLocation: null, shiftStart: '08:00', shiftEnd: '20:00' },
      ]);

    } catch (error) {
      console.error('Error loading optimization data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className={`bg-white rounded-lg p-6 shadow-sm ${className}`}>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="space-y-3">
            <div className="h-3 bg-gray-200 rounded"></div>
            <div className="h-3 bg-gray-200 rounded w-3/4"></div>
            <div className="h-3 bg-gray-200 rounded w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
        <div className="flex items-center space-x-2 text-sm text-gray-500">
          <Activity className="h-4 w-4" />
          <span>Last updated: {new Date().toLocaleTimeString()}</span>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Analytics */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Revenue Analytics</h3>
            <DollarSign className="h-6 w-6 text-green-600" />
          </div>
          {optimizationMetrics && (
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Total Revenue:</span>
                <span className="text-lg font-semibold text-gray-900">${optimizationMetrics.totalRevenue.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Revenue/Hour:</span>
                <span className="text-sm font-medium text-gray-900">${optimizationMetrics.revenuePerHour.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Loaded Mile Ratio:</span>
                <span className="text-sm font-medium text-gray-900">{(optimizationMetrics.loadedMileRatio * 100).toFixed(1)}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Total Trips:</span>
                <span className="text-sm font-medium text-gray-900">{optimizationMetrics.totalTrips}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Avg Revenue/Trip:</span>
                <span className="text-sm font-medium text-gray-900">${optimizationMetrics.averageRevenuePerTrip.toFixed(2)}</span>
              </div>
            </div>
          )}
        </div>

        {/* Backhaul Opportunities */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Backhaul Opportunities</h3>
            <Link className="h-6 w-6 text-blue-600" />
          </div>
          {optimizationMetrics && (
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Available Pairs:</span>
                <span className="text-lg font-semibold text-gray-900">{optimizationMetrics.backhaulPairs}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Avg Efficiency:</span>
                <span className="text-sm font-medium text-gray-900">{(optimizationMetrics.averageEfficiency * 100).toFixed(1)}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Potential Increase:</span>
                <span className="text-sm font-medium text-green-600">+${optimizationMetrics.potentialRevenueIncrease.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Total Miles:</span>
                <span className="text-sm font-medium text-gray-900">{optimizationMetrics.totalMiles.toFixed(1)} mi</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Loaded Miles:</span>
                <span className="text-sm font-medium text-gray-900">{optimizationMetrics.loadedMiles.toFixed(1)} mi</span>
              </div>
            </div>
          )}
        </div>

        {/* Unit Management */}
        {showUnitManagement && (
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Unit Management</h3>
              <Activity className="h-6 w-6 text-purple-600" />
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Available Units:</span>
                <span className="text-lg font-semibold text-green-600">{units.filter(u => u.status === 'AVAILABLE').length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">On Call:</span>
                <span className="text-sm font-medium text-yellow-600">{units.filter(u => u.status === 'ON_CALL').length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Total Units:</span>
                <span className="text-sm font-medium text-gray-900">{units.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">BLS Capable:</span>
                <span className="text-sm font-medium text-gray-900">{units.filter(u => u.capabilities.includes('BLS')).length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">ALS Capable:</span>
                <span className="text-sm font-medium text-gray-900">{units.filter(u => u.capabilities.includes('ALS')).length}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Backhaul Pairs List */}
      {showBackhaulPairs && backhaulPairs.length > 0 && (
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Recommended Backhaul Pairs</h3>
            <Target className="h-5 w-5 text-blue-600" />
          </div>
          <div className="space-y-4">
            {backhaulPairs.slice(0, 5).map((pair, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <Link className="h-5 w-5 text-blue-600" />
                    <span className="text-sm font-medium text-gray-900">Pair #{index + 1}</span>
                    <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                      Efficiency: {(pair.efficiency * 100).toFixed(1)}%
                    </span>
                  </div>
                  <span className="text-sm font-semibold text-green-600">+${pair.revenueBonus.toFixed(2)} bonus</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                  <div className="bg-white rounded p-3">
                    <div className="font-medium text-gray-900 mb-1">Request 1</div>
                    <div>Patient: {pair.request1?.patientId || 'N/A'}</div>
                    <div>Level: {pair.request1?.transportLevel || 'N/A'}</div>
                    <div>Priority: {pair.request1?.priority || 'N/A'}</div>
                  </div>
                  <div className="bg-white rounded p-3">
                    <div className="font-medium text-gray-900 mb-1">Request 2</div>
                    <div>Patient: {pair.request2?.patientId || 'N/A'}</div>
                    <div>Level: {pair.request2?.transportLevel || 'N/A'}</div>
                    <div>Priority: {pair.request2?.priority || 'N/A'}</div>
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between text-xs text-gray-500">
                  <span>Distance: {pair.distance.toFixed(1)} mi</span>
                  <span>Time Window: {pair.timeWindow} min</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Performance Metrics */}
      <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Performance Metrics</h3>
          <BarChart3 className="h-5 w-5 text-indigo-600" />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">
              {optimizationMetrics ? (optimizationMetrics.loadedMileRatio * 100).toFixed(1) : '0.0'}%
            </div>
            <div className="text-sm text-gray-600">Loaded Mile Ratio</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">
              ${optimizationMetrics ? optimizationMetrics.revenuePerHour.toFixed(0) : '0'}/hr
            </div>
            <div className="text-sm text-gray-600">Revenue per Hour</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">
              {optimizationMetrics ? optimizationMetrics.totalTrips : 0}
            </div>
            <div className="text-sm text-gray-600">Total Trips</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">
              {backhaulPairs.length}
            </div>
            <div className="text-sm text-gray-600">Backhaul Pairs</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RevenueOptimizationPanel;
